package com.stepdefinition;

import java.io.IOException;

import com.page.Invalid_Login_Details_page;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Invalid_Login_Details_Stepdefinition extends Invalid_Login_Details_page{
	@Given("^Open the url in the browser$")
	public void open_the_url_in_the_browser()  {
		 // launchs chrome browser
	 Launch("chrome", "http://automationpractice.com/index.php"); 
	 // Launching Loga Automation Practice website by entering the url
	}

	@When("^click Signin$")
	public void click_signin()  {
	    
	 Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a"); 
	// Inspected signin button by its xpath and clicking signin
	}

	@When("^Enter invalid Usernameandpassword$")
	public void enter_valid_Usernameandpassword() throws IOException  {
	 
	for(int j=1;j<=2;j++)
	{
		usernameandpassword(j);
		Click("//*[@id=\"SubmitLogin\"]/span"); 
		if(j<=2)
		{
			Launch("chrome", "http://automationpractice.com/index.php"); 
			Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a"); 
   // user name and password read through the data given in the excel sheet and following is the code
		}
	}
	}
	@Then("^Click on Signin$")
	public void click_on_Signin()  {
	   
	  Click("//*[@id=\"SubmitLogin\"]/span");  
	  // Inspected signin button by its xpath and clicked on Signin
	}
	@Then("^popuP message is displayed$")
	public void popuP_message_is_displayed()  {
	       
		  Assertion("//*[@id=\"center_column\"]/div[1]/ol/li");
// Pop message will be displayed on unsuccessful login 
	}
	
}
