package com.testrunner;

import org.junit.runner.RunWith;


import cucumber.api.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/main/resources/feature/Loga.feature",
		plugin = {"pretty", "html:reports/cucumber-html-report"},
		tags= {"@TC_01","@TC_02","@TC_03","@TC_04","@TC_05"},
		glue= {"com.definition"},
		monochrome=true
		)

public class Login_and_register {

}
