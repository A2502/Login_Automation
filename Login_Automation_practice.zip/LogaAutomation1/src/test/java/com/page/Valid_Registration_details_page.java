package com.page;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Valid_Registration_details_page {
	WebDriver driver;
	public void Launching(String browser,String URL)
	//method for launching the chrome browser
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("internetexplorer"))
		{
			System.setProperty("webdriver.ie.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		driver.manage().window().maximize(); // to maximize window
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
		driver.get("https://google.com");
	System.out.println(driver.getTitle());
	}
	public void Entering(String xpath,String values) 
	// method for entering registration details such as first name, last name, address, mobile number etc..
	{
		driver.findElement(By.xpath(xpath)).sendKeys(values);
	}
	public void clicking(String xpath)
	// method for clicking create an account after entering all the details
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void AsseRtion(String xpath)
	{
	

		String s1 = driver.findElement(By.xpath(xpath)).getText();
		Assert.assertEquals("Welcome to your account. Here you can manage all of your personal information and orders.", s1);
		System.out.println("Registration successful");
	}
	public void invalid_login() throws IOException
	{
		TakesScreenshot t = (TakesScreenshot)driver;
		File f = t.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Screenshots\\validRegistration.png"));
		// screenshot of valid registration page
	}
	}

