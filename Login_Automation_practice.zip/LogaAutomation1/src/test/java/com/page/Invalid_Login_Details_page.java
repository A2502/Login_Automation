package com.page;


import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.excelutility.Excel_1;



public class Invalid_Login_Details_page {
	WebDriver driver;
	public void Launch(String browser, String url)  
	//method for launching the chrome browser
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("internetexplorer"))
		{
			System.setProperty("webdriver.ie.driver", "C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Drivers\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		driver.manage().window().maximize(); // to maximize window
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
		driver.get("https://google.com");
System.out.println(driver.getTitle());
	}
	
	public void Signin(String xpath) 
	// method for signin of the Loga Automation Practice website
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void usernameandpassword(int j) throws IOException  
	// method for reading username and password through excel sheet
	{
		Excel_1 e=new Excel_1();
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(e.excel_username(j));
		WebElement d = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		d.click();
		driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(e.excel_password(j));
		WebElement f = driver.findElement(By.xpath("//*[@id=\"passwd\"]"));
		f.click();
	
	}
	public void Click(String xpath) // method for clicking signin after entering valid username and password
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void Assertion(String xpath)
	{
		String s1 = driver.findElement(By.xpath(xpath)).getText();
		Assert.assertEquals("Authentication failed", s1);
		System.out.println("login unsuccessful");
	}
	public void invalid_login() throws IOException
	{
		TakesScreenshot t = (TakesScreenshot)driver;
		File f = t.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("C:\\Users\\saiav\\Downloads\\LogaAutomation1\\src\\test\\resources\\Screenshots\\invalid.png")); 
		// screenshot of invalid login page
	}
}
